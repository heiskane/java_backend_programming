package com.example.helloThyme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloThymeApplicationTests {

	@Test
	void contextLoads() {
	}

}
