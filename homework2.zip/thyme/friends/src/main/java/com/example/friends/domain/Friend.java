package com.example.friends.domain;

public class Friend {

    String name;

    public Friend(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
